package com.arthur.peulotheshbon;

import com.adsdk.sdk.Ad;
import com.adsdk.sdk.AdListener;
import com.adsdk.sdk.AdManager;
import com.arthur.peulotheshbon.data.DatabaseHandler;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.*;

public class tab_result extends Activity implements AdListener {
	private AdManager mManager;
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab_results);
        DatabaseHandler db = new DatabaseHandler(this);
        ((TextView)findViewById(R.tabs.results_lb_average)).setText(getResources().getString(R.string.tab_results_lb_average) + " " + db.GetAverageMarks());
        db.close();
        if (!Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
        	((Button)findViewById(R.tabs.results_csv_save)).setEnabled(false);
    	}
        
        mManager = new AdManager(this, "http://my.mobfox.com/vrequest.php",
        		Data.Ads_Publisher, true);
		mManager.setListener(this);
		mManager.requestAd();
    }
    
	@Override
    protected void onResume() {
    	super.onResume();
    	DatabaseHandler db = new DatabaseHandler(this);
        ((TextView)findViewById(R.tabs.results_lb_average)).setText(getResources().getString(R.string.tab_results_lb_average) + " " + db.GetAverageMarks());
        db.close();
    }
	
    public void bt_watch_Click(View v)
    {
    	startActivity(new Intent(this, WatchResults.class));
    }
    
    public void bt_save_csv_Click(View v){
    	DatabaseHandler db = new DatabaseHandler(this);
    	db.ConvertToCsv();
    	db.close();
    }

	@Override
	public void adClicked() {
	}

	@Override
	public void adClosed(Ad arg0, boolean arg1) {
	}

	@Override
	public void adLoadSucceeded(Ad arg0) {
		if (mManager != null && mManager.isAdLoaded())
			mManager.showAd();
	}

	@Override
	public void adShown(Ad arg0, boolean arg1) {
	}

	@Override
	public void noAdFound() {
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		mManager.release();
	}
}
