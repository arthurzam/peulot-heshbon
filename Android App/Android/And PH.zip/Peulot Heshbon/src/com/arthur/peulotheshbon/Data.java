package com.arthur.peulotheshbon;

public final class Data {
	public static final String Ads_Publisher = "e47b1fbe233fd90ba877cf332cbd365c";
	public static int tab_chosen;
	public static int test_chosen;
	
	public static String full_name;
	public static boolean SaveMarks;
	public static int chosenDifficulty;
	
}
